<?php
    $host = 'localhost';
    $user = 'root';
    $key = '';
    $db = 'group_4_database';
    $mysql = mysqli_connect($host, $user, $key, $db);
?>